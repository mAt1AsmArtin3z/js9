// Aca va a importar la clase Persona desde persona.js
import { Persona } from './persona.js';

// Aca crea instancias de Persona y ejecuta el método mostrarInformacion
const persona1 = new Persona('Pepe', 20);
const persona2 = new Persona('Noria', 32);

console.log(persona1.mostrarInformacion());
console.log(persona2.mostrarInformacion());