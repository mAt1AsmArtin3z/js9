// Aca importa las funciones desde math.js
import { sumar, restar } from './math.js';

// Aca va a usar las funciones y las muéstrala por consola
const resultadoSuma = sumar(5, 3);
const resultadoResta = restar(5, 3);

console.log(`Suma: ${resultadoSuma}`);
console.log(`Resta: ${resultadoResta}`);