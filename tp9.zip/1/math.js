// Aca va a definir y exportar las funciones para sumar y restar
export function sumar(a, b) {
    return a + b;
  }
  
  export function restar(a, b) {
    return a - b;
  }
  